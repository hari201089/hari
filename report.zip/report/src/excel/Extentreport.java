package excel;

import java.io.File;

import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Extentreport {
	ExtentReports Reports;
	ExtentTest test;
	ExtentHtmlReporter htmlreporter;
	
@BeforeTest
	public void setup(){
		htmlreporter=new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/report.html"));
		htmlreporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/extent-Config.xml"));
		Reports=new ExtentReports();
		Reports.setSystemInfo("Environment","UAT");
		Reports.attachReporter(htmlreporter);
	}
	
@Test

}

}
