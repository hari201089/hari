package excel;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnReport {

	ExtentHtmlReporter Report;
	public ExtentReports extent;
	public ExtentTest  test;


	public void reportStep(String desc, String status) throws IOException {		
		if(status.equalsIgnoreCase("PASS")){
			test.log(Status.PASS, desc
					+test.addScreenCaptureFromPath("./snaps/snap4.jpeg"));				
		} else if(status.equalsIgnoreCase("FAIL")){			
			test.log(Status.FAIL, desc
					+test.addScreenCaptureFromPath("./snaps/snap3.jpeg"));
		} else if(status.equalsIgnoreCase("INFO")){			
			test.log(Status.INFO, desc
					+test.addScreenCaptureFromPath("./snaps/snap3.jpeg"));
		}
	}
	

	@BeforeSuite
	public void startResult(){	
		Report = new ExtentHtmlReporter("./reports/report.html");
		extent = new ExtentReports();
		Report.loadConfig("./src/main/resources/extent-Config.xml");
		//Report.loadConfig(new File("./src/main/resources/extent-Config.xml"));
	}
	
	@BeforeMethod
	public void startTestCase(){
		test=extent.createTest("TC001", "Creates a New Lead");
		//test =extent.startTest("TC001", "Creates a New Lead");
		test.assignCategory("smoke");
		test.assignAuthor("Sarath");
	}

/*	@AfterMethod	
	public void endTest(){
		extent.
		extent.endTest(test);
	}
*/
	@AfterSuite
	public void endResult(){
		extent.flush();	
	}

}
