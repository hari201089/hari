package testng;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Draganddrop extends Demo{
	@Test(dependsOnMethods={"browser"},alwaysRun=true)
	public void dragdrop(){
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",".\\driv\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://jqueryui.com/droppable/");
		//driver.manage().window().maximize();
		//WebElement fr=driver.findElementByClassName("demo-frame");
		
		Actions builder=new Actions(driver);
		
		WebElement fr=driver.findElementByClassName("demo-frame");
		driver.switchTo().frame(fr);
		WebElement drag=driver.findElementById("draggable");
		WebElement drop=driver.findElementById("droppable");
		builder.dragAndDrop(drag, drop).perform();
	}

}
