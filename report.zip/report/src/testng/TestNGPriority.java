package testng;

import org.testng.annotations.Test;

public class TestNGPriority {
  @Test
  public void a() {
  }
  @Test(priority=-20)
  public void b() {
  }
  @Test(priority=10)
  public void d() {
  }
  @Test(priority=9)
  public void c() {
  }
}
