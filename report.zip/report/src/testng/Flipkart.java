package testng;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Flipkart {
@Test
	public void mousehov() throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",".\\driv\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		//Load URL
		driver.get("https://www.flipkart.com/");
		//driver.manage().window().maximize();
		
		//Thread.sleep(5000);
		WebElement app=driver.findElementByXPath("//span[text()='Appliances']");
		Actions builder=new Actions(driver);
		Thread.sleep(5000);
		
		//builder.moveToElement(app).build().perform();
		builder.moveToElement(app).perform();
		
		Thread.sleep(5000);
		driver.findElementByXPath("//span[text()='Sony']").click();		
	}

}
