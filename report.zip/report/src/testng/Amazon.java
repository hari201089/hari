package testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Amazon {

RemoteWebDriver driver;
@Test
	public void invokeBrowser()  {
		System.setProperty("webdriver.chrome.driver", ".\\driv\\chromedriver.exe");
		driver=new ChromeDriver();

		driver.manage().deleteAllCookies();
		//driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.get("http://www.amazon.in");
		//Thread.sleep(5000);
		
		
		//driver.quit();
		

	}

	

}
