package testng;

import org.testng.annotations.Test;

public class TestNGDepends {
  @Test
  public void create() {
  }
  @Test(enabled=false)
  public void modify() {
  }
  @Test(dependsOnMethods={"modify"})
  public void update() {
  }
  @Test
  public void delete() {
  }
}
