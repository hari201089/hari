package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Demo {
WebDriver driver;
@Test(expectedExceptions=RuntimeException.class)
public void browser() throws Exception{
	System.setProperty("webdriver.chrome.driver", ".\\driv\\chromedriver.exe");
	driver = new ChromeDriver();
	
	driver.get("https://demo.guru99.com/v1");
	
	//Entering the username and password and click on Login
	driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr103096");
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys("agYsabu");
	Thread.sleep(3000);
	driver.findElement(By.xpath("//input[@value='LOGIN']")).click();
	Thread.sleep(5000);
	
	// Verify the text in the Home page
	String VerifyTxt = driver.findElement(By.xpath("//h2[text()='Gtpl Bank']")).getText();
	System.out.println(VerifyTxt);
	
	
	
	// Closing the Browser
	//driver.quit();
}
	

}
