package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();
		String str1="mary";
		String str2="amry";
		char[] ch1=str1.toCharArray();
		Arrays.sort(ch1);
		String sort1=new String(ch1);
		char[] ch2=str2.toCharArray();
		Arrays.sort(ch2);
		String sort2=new String(ch2);
		System.out.println(sort1.equals(sort2));

	}

}
