package practice;

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Am a hero";

String removespace=str.replaceAll(" ", "");
char[] ch=removespace.toCharArray();
System.out.println(removespace);
for(int i=ch.length-1;i>=0;i--){
	System.out.print(ch[i]);
}

	}

}
