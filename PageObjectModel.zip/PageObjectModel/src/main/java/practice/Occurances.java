package practice;

import java.util.Scanner;

public class Occurances {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner hari=new Scanner(System.in);
System.out.println("Enter the string");
String str=hari.nextLine();
System.out.println("Enter the character to check occurances");
char ch=hari.next().charAt(0);
System.out.println("");
int count=0;
for(char eachch:str.toCharArray()){
if(ch==eachch){
	count++;
}
}
System.out.println(count);
	}

}
