package practice;

public class Stringfunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s2="Hari";
		String s3="   test ng   ";
		String s4="T,e,s,t";
		
		//ToChararray
		String s1="hariharan";  
		char[] ch=s1.toCharArray();  
		for(char eachch:ch){
			System.out.println(eachch); 
		}
		
		//length();
		int len1=s1.length();
		System.out.println(len1);

		//CharAtIndex
		char c=s1.charAt(0);
		System.out.println(c);

		//indexof(chr)
		int indx=s1.indexOf('h');
		System.out.println(indx);

		//LastIndexof(chr)
		int lastindx=s1.lastIndexOf('l');
		System.out.println(lastindx);

		//concat
		String str3=s1.concat(s2);
		System.out.println(str3);

		//tostring
		//??

		//trim
		String trimstr=s3.trim();
		System.out.println(trimstr);

		//split
		String[] splitstr=s4.split(",");
		//System.out.println(splitstr.length);
		for(String s:splitstr){
			System.out.println(s);
		}

		//To lowercase
		String s5="I am Indian";
		String lowcase=s5.toLowerCase();
		String upcase=s5.toUpperCase();
		System.out.println(lowcase);
		System.out.println(upcase);

		//Startswith, Endswith, Contains
		System.out.println(s5.startsWith("I"));
		System.out.println(s5.contains("r"));
		System.out.println(s5.endsWith("n"));

		//Substring
		String sub=s5.substring(5);
		System.out.println(sub);
		String s6="Kamalhassan";
		String subportion=s6.substring(5);
		System.out.println(subportion);

		//Replace
		String company="Wipro(2017)";
		String replacechr=company.replace('W', 'G');
		System.out.println(replacechr);

		//ReplaceAll
		String companyname="Paypal(2018)";
		//print only numbers
		System.out.println(companyname.replaceAll("\\D", ""));
		//ignore all the numbers and the print the rest
		System.out.println(companyname.replaceAll("\\d", ""));
		//ignores special characters and numbers
		System.out.println(companyname.replaceAll("[^A-Za-z]", ""));





	}
}