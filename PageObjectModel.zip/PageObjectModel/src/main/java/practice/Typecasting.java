package practice;
import java.util.Scanner;

public class Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="1234";
		System.out.println(str1);
		int i=Integer.parseInt(str1);
		System.out.println(i);
		String str2=String.valueOf(i);
		System.out.println(str2);
}
}