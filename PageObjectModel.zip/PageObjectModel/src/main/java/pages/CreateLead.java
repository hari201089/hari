package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class CreateLead extends LeafTapsWrappers{
	public CreateLead(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("Create Lead | opentaps CRM")){
			reportStep("This is not My create lead Page", "FAIL");
		}		
	}
	public CreateLead entercompanyname(String data){
		enterById("createLeadForm_companyName", data);
		return this;
	}
	public CreateLead enterfirstname(String data){
		enterById("createLeadForm_firstName", data);
		return this;
	}
	public CreateLead enterlastname(String data){
		enterById("createLeadForm_lastName", data);
		return this;
	}
	public ViewLeads clickcreatelead(){
		clickByClassName("smallSubmit");
		return new ViewLeads(driver, test);
		
	}
}
