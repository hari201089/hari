package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class MergeLead extends LeafTapsWrappers {
	public MergeLead(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("Merge Leads | opentaps CRM")){
			reportStep("This is not merge lead Page", "FAIL");
		}		
	} 
	public Merge_FindLeads clickFromLead(){
		clickByXpath("//table[@id='widget_ComboBox_partyIdFrom']/../a");
		switchToLastWindow();
		return new Merge_FindLeads(driver, test);
	}
	public MergeLead verify_sectionheader(String data){
		verifyTextById("sectionHeaderTitle_leads", data);
		return this;
	}

	public Merge_FindLeads clickToLead(){
		clickByXpath("//table[@id='widget_ComboBox_partyIdTo']/../a");
		switchToLastWindow();
		return new Merge_FindLeads(driver, test);
	}
	public ViewLeads clickmerge(){
		clickByLinkNoSnap("Merge");
		acceptAlert();
		return new ViewLeads(driver, test);
		
		
	}
}
