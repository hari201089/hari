package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class Merge_FindLeads extends LeafTapsWrappers {
	public Merge_FindLeads(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("Find Leads")){
			reportStep("This is not merge-find lead Page", "FAIL");
		}		
	}  
	public Merge_FindLeads enterfrom_leadid(String data){
		enterByXpath("//div[@class='x-form-element']/input",data);
		return this;
		
	}
	public Merge_FindLeads clickfindleads_merge(){
		clickByXpath("//button[text()='Find Leads']");
		return this;
	}
	public MergeLead clickonlink_fromleadid() throws InterruptedException{
		waitfn();
		clickByXpathNoSnap("(//a[@class='linktext'])[1]");
		switchToParentWindow();
		return new MergeLead(driver, test);
	}
	public Merge_FindLeads enterTo_leadid(String data){
		enterByXpath("//div[@class='x-form-element']/input",data);
		return this;
		
	}

}
