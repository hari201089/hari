package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class FindLeads extends LeafTapsWrappers{
	public FindLeads(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("Find Leads | opentaps CRM")){
			reportStep("This is not find lead Page", "FAIL");
		}		
	} 
	
public FindLeads enterfirstname(String data){
	
enterByXpath("(//input[@name='firstName'])[3]",data);
return this;
}

public FindLeads clickbuttonfindleads() throws InterruptedException{
	clickByXpath("//button[text()[contains(.,'Find Leads')]]");
	waitfn();
	return this;
}
public ViewLeads clickLeadId(String data){
	clickByLink(data);
	return new ViewLeads(driver, test);
}
public FindLeads enterleadid(String data){
	enterByXpath("(//div[@class='x-form-element']/input)[13]", data);
	return this;
}
public FindLeads verifyerrormsg(String data){
	verifyTextByXpath("//div[@class='x-paging-info']",data);
	return this;
}
public FindLeads clickphonetab(){
	clickByXpath("(//em[@class='x-tab-left'])[2]");
	return this;
}
public FindLeads enterphonecountrycode(String data){
	enterByName("phoneCountryCode",data);
	return this;
}
public FindLeads enterphoneareacode(String data){
	enterByName("phoneAreaCode",data);
	return this;
}
public FindLeads enterphonenum(String data){
	enterByName("phoneNumber",data);
	return this;
}
public FindLeads verifyfirstresultinglead(String data){
	verifyTextByXpath("(//a[@class='linktext'])[6]",data);
	return this;
}
public ViewLeads clickfirstresultinglead(){
	clickByXpath("(//a[@class='linktext'])[4]");
	return new ViewLeads(driver, test);
}
public FindLeads clickemailtab(){
	clickByXpath("(//em[@class='x-tab-left'])[3]");
	return this;
}
public FindLeads entermailaddress(String data){
	enterByName("emailAddress", data);
	return this;
}
public ViewLeads clickfirstleadname(){
	clickByXpath("(//a[@class='linktext'])[6]");
	return new ViewLeads(driver, test);
}

}
