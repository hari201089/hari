package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class ViewLeads extends LeafTapsWrappers{
	public ViewLeads(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("View Lead | opentaps CRM")){
			reportStep("This is not view lead Page", "FAIL");
		}		
	} 
	public ViewLeads verifyfname(String data){
		verifyTextById("viewLead_firstName_sp", data);
		return this;
	}
	public EditLead clickeditlead(){
		clickByLink("Edit");
		return new EditLead(driver, test);
	}
	public void verifycompanyname(String data){
		verifyTextById("viewLead_companyName_sp", data);
	}
	public FindLeads clickfindleads_view(){
		clickByLink("Find Leads");
		return new FindLeads(driver, test);
	}
	public MyLeads clickdeletelead(){
		clickByLink("Delete");
		return new MyLeads(driver, test);
	}
	public DuplicateLead clickduplicatelead(){
		clickByLink("Duplicate Lead");
		return new DuplicateLead(driver, test);
	}
}
