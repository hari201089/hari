package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC004_EditLead extends LeafTapsWrappers {
	@BeforeClass
	public void testDetails(){
	
		testCaseName = "TC004_EditLead";
		testDescription = "Edit Lead";
		category = "Smoke";
		authors = "Hari";
		browserName = "chrome";
		dataSheetName = "TC004";
		
	}
	
	@Test(dataProvider="fetchData")
	public void editLd(String UName, String Pwd, String LgdUser,String CRMHeader,String fname,String leadid,String NewCname,String updCname) throws InterruptedException{
		new LoginPage(driver, test)
		.enterUserName(UName)
		.enterPassword(Pwd)
		.clickLogin()
		.verifyLoginName(LgdUser)
		.clickcrmlink()
		.verifyCRMPage(CRMHeader)
		.clickmainleads()
		.clickfindleads()
		.enterfirstname(fname)
		.clickbuttonfindleads()
		.clickLeadId(leadid)
		.clickeditlead()
		.editcompanyname(NewCname)
		.clickupdate()
		.verifycompanyname(updCname);
							
		}
}
