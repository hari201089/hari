package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC003_CreateLead extends LeafTapsWrappers {
	@BeforeClass
	public void testDetails(){
	
		testCaseName = "TC003_CreateLead";
		testDescription = "Create Lead";
		category = "Smoke";
		authors = "Hari";
		browserName = "chrome";
		dataSheetName = "TC003";
		
	}
	
	@Test(dataProvider="fetchData")
	public void createld(String UName, String Pwd, String LgdUser,String CRMHeader,String cname,String fname,String lname){
		new LoginPage(driver, test)
		.enterUserName(UName)
		.enterPassword(Pwd)
		.clickLogin()
		.verifyLoginName(LgdUser)
		.clickcrmlink()
		.verifyCRMPage(CRMHeader)
		.clickmainleads()
		.clickcreateleads()
		.entercompanyname(cname)
		.enterfirstname(fname)
		.enterlastname(lname)
		.clickcreatelead()
		.verifyfname(fname);
	}

}
