package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC007_DuplicateLead extends LeafTapsWrappers {
	@BeforeClass
	public void testDetails(){
	
		testCaseName = "TC007_DuplicateLead";
		testDescription = "Duplicate Lead";
		category = "Smoke";
		authors = "Hari";
		browserName = "chrome";
		dataSheetName = "TC007";
		
	}
	
	@Test(dataProvider="fetchData")
	public void editLd(String UName, String Pwd, String LgdUser,String CRMHeader,String mailid,String fname,String pageheader) throws InterruptedException{
		new LoginPage(driver, test)
		.enterUserName(UName)
		.enterPassword(Pwd)
		.clickLogin()
		.verifyLoginName(LgdUser)
		.clickcrmlink()
		.verifyCRMPage(CRMHeader)
		.clickmainleads()
		.clickfindleads()
		.clickemailtab()
		.entermailaddress(mailid)
		.clickbuttonfindleads()
		.verifyfirstresultinglead(fname)
		.clickfirstleadname()
		.clickduplicatelead()
		.verifyheader_duplicate(pageheader)
		.clickcreatelead_duplicate()
		.verifyfname(fname);
									
		}
}
