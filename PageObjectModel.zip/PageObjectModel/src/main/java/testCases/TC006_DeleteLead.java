package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC006_DeleteLead extends LeafTapsWrappers {
	@BeforeClass
	public void testDetails(){
	
		testCaseName = "TC006_DeleteLead";
		testDescription = "Delete Lead";
		category = "Smoke";
		authors = "Hari";
		browserName = "chrome";
		dataSheetName = "TC006";
		
	}
	
	@Test(dataProvider="fetchData")
	public void editLd(String UName, String Pwd, String LgdUser,String CRMHeader,String countrycode,String areacode,String phonenum,String firstleadname) throws InterruptedException{
		new LoginPage(driver, test)
		.enterUserName(UName)
		.enterPassword(Pwd)
		.clickLogin()
		.verifyLoginName(LgdUser)
		.clickcrmlink()
		.verifyCRMPage(CRMHeader)
		.clickmainleads()
		.clickfindleads()
		.clickphonetab()
		.enterphonecountrycode(countrycode)
		.enterphoneareacode(areacode)
		.enterphonenum(phonenum)
		.verifyfirstresultinglead(firstleadname)
		.clickfirstresultinglead()
		.clickdeletelead()
		.clickfindleads();
		
		
		
		
									
		}
}
