//Program to remove white spaces in given string
package sample;

public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="YOUR SUCCESS BEGINS TODAY";
String replaceString=str.replaceAll("\\s","");  
System.out.println(replaceString);  
	}
}
