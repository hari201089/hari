package sample;

public class Numberofchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="COGNIZANT INDIA";
String[] e=str.split("e");
int len=e.length;
String[] a=str.split("a");
int len1=a.length;
System.out.println(len-1);
System.out.println(len1-1);

	}

}
