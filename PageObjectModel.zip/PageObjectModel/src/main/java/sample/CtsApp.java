package sample;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import wrappers.LeafTapsWrappers;
public class CtsApp extends LeafTapsWrappers {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://www.smoi.t-systems.com/sm-oi-prod/index.do");
		driver.manage().window().maximize();
		driver.findElementById("LoginUsername").sendKeys("005L8LV");
		driver.findElementById("LoginPassword").sendKeys("Incident1230&");
		driver.findElementById("loginBtn").click();
		WebDriverWait wait=new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@id='commonMsg']"))).click();
		driver.findElementByXPath("//button[text()='Close']").click();
		driver.findElementByXPath("//span[text()='Problem Management']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("//span[text()='Search Problems']").click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement fr=driver.findElementByXPath("//iframe[@src='/sm-oi-prod/cwc/nav.menu?name=navStart&id=ROOT%2FProblem%20Management%2FSearch%20Problems']");
		driver.switchTo().frame(fr);
		driver.findElementByXPath("//div[@id='X13Edit']/input").sendKeys("pm14054");
		driver.switchTo().defaultContent();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//button[text()='Search']").click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='RCA related PRM set to false']"))).click();
		driver.findElementByXPath("//button[text()='Close']").click();
		WebElement pfr=driver.findElementByXPath("//iframe[contains(@title,'Problem:')]");
		driver.switchTo().frame(pfr);
		driver.findElementByXPath("//a[contains(@title,'Updates')]").click();
		driver.findElementByXPath("//a[contains(@title,'Activities')]").click();
		driver.findElementByXPath("//a[contains(@title,'Journal Updates')]").click();
		String text=driver.findElementByXPath("//p[contains(.,'This problem ticket is related to the incident')]/..").getText();
		System.out.println("Ticket details"+text);
		//driver.close();
		}
}
