package sample;
import java.util.Scanner;

public class Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari=new Scanner(System.in);
		String str=hari.nextLine();
		int len=str.length();
		char[] arr1=str.toCharArray();
		for(int i=0;i<len;i++){
			int x=(int) arr1[i];
			System.out.println(x);
			char y=(char)(x+1);
			System.out.print(y);
			}
hari.close();
	}
}
