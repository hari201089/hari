/*//Program to count number of vowels and consonants
package sample;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class PrintMaxRepeatMap
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "HEXAWARE";
		char[] ch=str.toCharArray();
		Map<Character,Integer> map1=new LinkedHashMap<Character,Integer>();
		//int count=1;
		for(char eachch:ch){
			if(!map1.containsKey(eachch)){
				map1.put(eachch, 1);

			}
			else
			{

				//System.out.println("It has dups ");
				map1.put(eachch,map1.get(eachch)+1);

				//map1.get(eachch);
				//System.out.println(map1.put(eachch,map1.get(eachch)+1));
				//break;
			}		

		}
		System.out.println(map1);
		for(Map <char[],> eachmap:map1){
			
		}

	}   
}


*/