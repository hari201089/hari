package sample;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import wrappers.LeafTapsWrappers;
public class CtsApp2 extends LeafTapsWrappers {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://www.smoi.t-systems.com/sm-oi-prod/index.do");
		driver.manage().window().maximize();
		driver.findElementById("LoginUsername").sendKeys("005L8LV");
		driver.findElementById("LoginPassword").sendKeys("Incident1230&");
		driver.findElementById("loginBtn").click();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement popup;
		WebDriverWait wait=new WebDriverWait(driver, 30);
		popup= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//p[@id='commonMsg']")));
		popup.click();
		driver.findElementByXPath("//button[text()='Close']").click();
		//driver.findElementById("commonMsg").
		driver.findElementByXPath("//span[text()='Problem Management']").click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//span[text()='Problem Queue']"))).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement fr=driver.findElementByXPath("//iframe[@title='Problem Queue: Open Problems Assigned to My Group']");
		driver.switchTo().frame(fr);
		System.out.println("Switched to frame");
		/*WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
		List<WebElement> rows= table.findElements(By.tagName("tr"));
		int rowcount=rows.size();
		System.out.println(rowcount);
		WebElement row1=rows.get(0);
		List<WebElement> col=row1.findElements(By.tagName("td"));
		int colcount=col.size();
		System.out.println(colcount);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		int i=0;
		while(i<rowcount){
			String tablefinal=table.getText();
			System.out.print(tablefinal+"   ");
			System.out.println();
			i=i+1;
		}*/
       // String webtable=driver.findElementByXPath("//*[@id="ext-gen-list-1-14"]").getText();
        
        
        
        /*for(WebElement tableData:driver.findElements(By.tagName("tr")){
			System.out.print(tableData.getText()+"   ");
							}*/
		//System.out.println();
}}

/*
WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
List<WebElement> rows= table.findElements(By.tagName("tr"));
int rowcount=rows.size();
System.out.println(rowcount);
WebElement row1=rows.get(0);
List<WebElement> col=row1.findElements(By.tagName("td"));
int colcount=col.size();
System.out.println(colcount);
Thread.sleep(5000);
int i=0;
while(i<rowcount){
	String tablefinal=table.getText();
	System.out.print(tablefinal+"   ");
	System.out.println();
	i=i+1;
}
*/