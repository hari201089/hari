//String txt="YOUR SUCCESS BEGINS TODAY"
//Java program to print duplicate character from the given string.
package sample;

public class DuplicateCharacter {
	public static void main(String[] args){
		String txt="YOUR SUCCESS BEGINS TODAY";
		char [] input = txt.toCharArray(); 
		System.out.println("Duplicate Characters are as follows:"); 
		for(int i=0;i<txt.length();i++) 
		{ 
			for(int j=i+1;j<txt.length();j++) 
			{ 
				if(input[i]==input[j]) 
				{ 
					System.out.println(input[j]); 
					break; 
				} 
			} 
		} 

	}

}
