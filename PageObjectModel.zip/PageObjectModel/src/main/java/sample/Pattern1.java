package sample;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pattern1="[0-9]+";
		Pattern p = Pattern.compile(pattern1);
		//String pattern = "Amazon has 102014 employess in India and 24500 in USA";
		Matcher match=p.matcher("Amazon has 102014 employess in India and 24500 in USA");
		//System.out.println(match.group());
		int sum=0;
		while(match.find()){
			System.out.println(match.group());
			
			int str1=Integer.parseInt(match.group());
			sum=sum+str1;
			
		}

		System.out.println(sum);
	}
}



