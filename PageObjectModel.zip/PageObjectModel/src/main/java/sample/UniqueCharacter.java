//Program to count number of vowels and consonants
package sample;

public class UniqueCharacter
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "YOUR SUCCESS BEGINS TODAY";
		String res="";
		for (int i=0;i<str.length();i++){
			int count=0;
			for(int j=0;j<res.length();j++){
				if(str.charAt(i)==res.charAt(j)){
					count++;
				}

			}
			if(count==0){
				res = res+str.charAt(i);
			}
		}
		System.out.println("Output string with only unique characters:"+res);
		String unique=res.replaceAll("\\s","");
		int uniquecount=unique.length();
		System.out.println("Total number of unique characters is "+uniquecount);

	}   
}


