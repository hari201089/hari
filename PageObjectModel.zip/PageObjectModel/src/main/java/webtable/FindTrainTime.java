package webtable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindTrainTime {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://erail.in");
		driver.manage().window().maximize();
		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("KPD",Keys.TAB);
		driver.findElementById("chkSelectDateOnly").click();
		Thread.sleep(5000);
		WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
		List<WebElement> rows= table.findElements(By.tagName("tr"));
		int rowcount=rows.size();
		System.out.println(rowcount);
		WebElement row1=rows.get(0);
		List<WebElement> col=row1.findElements(By.tagName("td"));
		int colcount=col.size();
		System.out.println(colcount);
		Thread.sleep(5000);
		int i=0;
		while(i<rowcount){
			String tablefinal=table.getText();
			System.out.print(tablefinal+"   ");
			System.out.println();
			i=i+1;
		}
		
		
	/*	String arrival=col.get(5).getText();
		System.out.println("Arrival time is "+arrival);
		for(int i=0;i<colcount;i++){
			for(int j=1;j<rowcount;i++){
				//for(WebElement tabledata:col){
				String traindetails=table.getText();
				System.out.print(traindetails+"  ");
			//}
			System.out.println();
		}}*/
}}

