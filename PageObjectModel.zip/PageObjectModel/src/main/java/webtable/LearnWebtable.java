/*package webtable;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class LearnWebtable {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.get("https://www.savaari.com/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("from_city").sendKeys("Chennai",Keys.ARROW_DOWN.ENTER);
		driver.findElementById("to_city_1").sendKeys("Bangalore",Keys.ARROW_DOWN.ENTER);
		driver.findElementById("go").click();
		//div[@class='large-12 columns']
		WebElement grid=driver.findElementByXPath("//div[@class='row bar-modify']/..");
		WebElement block=driver.findElementByXPath("//div[contains(@id,'result_block')]/div/following-sibling::div/div/div/div"[4]);
		String price=block.getText();
		System.out.println(price);*/
		

	













