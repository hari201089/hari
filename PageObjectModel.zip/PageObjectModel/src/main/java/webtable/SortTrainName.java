package webtable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.ArrayList;

public class SortTrainName {
	ArrayList<String> al=new ArrayList<String>();
	ArrayList<String> al2=new ArrayList<String>();
	public void trainname(){
		try{
			// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
			ChromeDriver driver = new ChromeDriver();
			//Load URL
			driver.get("https://erail.in");
			driver.manage().window().maximize();
			driver.findElementById("txtStationFrom").clear();
			driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
			driver.findElementById("txtStationTo").clear();
			driver.findElementById("txtStationTo").sendKeys("TPTY",Keys.TAB);
			driver.findElementById("chkSelectDateOnly").click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//Thread.sleep(5000);
			WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
			List<WebElement> rows= table.findElements(By.tagName("tr"));
			int rowcount=rows.size();
			System.out.println(rowcount);
			WebElement row1=rows.get(0);
			int firstrow=rows.indexOf(row1);
			List<WebElement> col=row1.findElements(By.tagName("td"));
			int colcount=col.size();
			System.out.println(colcount);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String arrival=col.get(5).getText();
			System.out.println("Arrival time is "+arrival);
			String trainname1=null;
			for (int j = firstrow; j < rowcount; j++) {
				trainname1=rows.get(j)
						.findElements(By.tagName("td"))
						.get(1).getText();
				al.add(trainname1);
			}
			Collections.sort(al);
			for(String s:al)
			{
				System.out.println("TrainNamelistal - "+s);
			}
			driver.findElementByLinkText("Train Name").click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
			rows= table.findElements(By.tagName("tr"));
			String trainname2=null;
			for (int j = firstrow; j < rowcount; j++) {
				trainname2=rows.get(j)
						.findElements(By.tagName("td"))
						.get(1).getText();
				al2.add(trainname2);
			}
			for(String s2:al2)
			{
				System.out.println("TrainNameal2 - "+s2);

			}
			if(al==al2){
				System.out.println("Value matches");
			}
			else
			{
				System.out.println("Value not matches");
			}

			//driver.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Exception occurred");
		}

	}
	public static void main(String[] args) throws InterruptedException{
		SortTrainName obj = new SortTrainName();
		obj.trainname();
	}


}

