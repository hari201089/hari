/*package aui;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import wrappers.LeafTapsWrappers;
public class Draggable extends LeafTapsWrappers {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("http://jqueryui.com/sortable/");
		driver.manage().window().maximize();
		WebElement fr=driver.findElementByClassName("demo-frame");
		driver.switchTo().frame(fr);
		dri
		WebElement item1=driver.findElementByXPath("//li[text()='Item 1']/span");
		int item5=driver.findElementByXPath("//li[text()='Item 5']/span").getLocation().getY();
		//int item6=driver.findElementByXPath("//li[text()='Item 6']/span").getLocation().getY();
		Actions builder=new Actions(driver);
		builder.dragAndDropBy(item1, 0, item5+2).build().perform();
		
		
	
	}
}
*/