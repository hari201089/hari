package aui;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import wrappers.LeafTapsWrappers;
public class MouseHover extends LeafTapsWrappers {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		//Thread.sleep(5000);
		WebElement app=driver.findElementByXPath("//span[text()='Appliances']");
		Actions builder=new Actions(driver);
				Thread.sleep(5000);
		builder.moveToElement(app).build().perform();
		Thread.sleep(5000);
		driver.findElementByXPath("//span[text()='Sony']").click();		
		}
}
