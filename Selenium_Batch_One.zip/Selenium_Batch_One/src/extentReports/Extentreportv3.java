package extentReports;

import org.junit.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Extentreportv3 {
	ExtentReports reports;
	ExtentHtmlReporter htmlReporter;
	ExtentTest test;

	@BeforeTest
	public void starttest() {
		// specify where your report file will be stored
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "//test-output//report.html");

		// attach the html file to extent reports
		reports = new ExtentReports();
		reports.attachReporter(htmlReporter);
		
		//load extent-config file
	  // htmlReporter.loadXMLConfig("./src/main/resources/extent-config.xml");

		// configure environment info
		reports.setSystemInfo("Hostname", "localhost");
		reports.setSystemInfo("Browser", "chrome");
		reports.setSystemInfo("Environment", "UAT");
		reports.setSystemInfo("Region", "UA1");
		
	}

	@Test
	public void passtest() {

		// map test case to Extent test
		test = reports.createTest("passtest");
		// create dummy pass case
		System.out.println("This is my pass method");
		Assert.assertTrue(true);
        test.pass("test passed");
	}

	@Test
	public void failtest() {
		test = reports.createTest("failtest");
		System.out.println("This is fail method");
		Assert.assertFalse(false);
		test.fail("test failed");
	}

	@Test
	public void skiptest() {
		test = reports.createTest("skiptest");
		System.out.println("This is skip method");
		throw new SkipException("Skip Test forcefully");
	}
@AfterMethod
public void setTestresults(ITestResult result){
	if(result.getStatus()== ITestResult.FAILURE){
		test.fail(result.getName());
		test.fail(result.getThrowable());
	}
	else if(result.getStatus()== ITestResult.SUCCESS){
		test.pass(result.getName());
	}
	else if(result.getStatus()== ITestResult.SKIP){
		test.skip("Test case:"+result.getName()+"has been skipped");
	}
}
	@AfterTest
	public void endtest() {
		reports.flush();
	}
}
