package wrappers;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class ProjectSpecificWrapper extends GenericWrappers {
	@Parameters({"browsername","URL","userName","password"})
	@BeforeMethod(groups={"common"})
	public void Login(String browserName,String url,String userName,String passWord) {
		// TODO Auto-generated method stub
		invokeApp(browserName, url);
		enterById("username", userName);
		enterById("password", passWord);
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");

	}
	@AfterMethod(groups={"common"})
	public void quitbrowser(){
		closeAllBrowsers();
	}
	}


