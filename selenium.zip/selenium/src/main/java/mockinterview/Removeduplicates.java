package mockinterview;

import java.util.Set;
import java.util.TreeSet;

public class Removeduplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str={"1,2,2,6,7,3,4,4,5,5,6,7"};
		char[] ch=str.toString().toCharArray();

		//int len=ch.length;
		Set <Character> s=new TreeSet<Character>();
		for(char eachch:ch){
			s.add(eachch);


		}

		System.out.println(s);
	}
}
