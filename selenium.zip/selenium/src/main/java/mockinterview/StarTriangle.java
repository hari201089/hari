package mockinterview;

public class StarTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k=0;
		int rows=5;
		for(i=1;i<=rows;i++){
			for(j=1;j<rows-i;j++){
				System.out.print(" ");
			}
			while(k!=(2*i-1)){
				System.out.print("*");
				k++;
			}
			k=0;
			System.out.println();
			
			
		}
		
	}

}
