package mockinterview;

import java.util.Arrays;

public class AnagramString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="army";
		String str2="mary";
		char[] ch1=str1.toCharArray();
		char[] ch2=str2.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		String s1=new String(ch1);
		String s2=new String(ch2);
		System.out.println(s1.equals(s2));

	}

}
