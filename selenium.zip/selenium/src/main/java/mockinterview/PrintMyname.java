package mockinterview;

public class PrintMyname {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String strname="Hariharan";
		char[] ch=strname.toCharArray();
		for(char eachchar:ch){
			System.out.println(eachchar);
		}

	}

}
