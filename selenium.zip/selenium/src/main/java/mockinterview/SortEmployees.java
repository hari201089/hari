package mockinterview;

import java.util.ArrayList;
import java.util.Collections;

public class SortEmployees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();
		al.add("John");
		al.add("Pradeep");
		al.add("Mary");
		al.add("Ramya");
		Collections.sort(al);
		for(String s:al){
			System.out.println(s);
		}

	}

}
