package week1day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class Irctcsignup {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://www.irctc.co.in/eticketing/loginHome.jsf");
		driver.manage().window().maximize();
		driver.findElementByLinkText("Sign up").click();
		driver.findElementById("userRegistrationForm:userName").sendKeys("hari89");
		driver.findElementById("userRegistrationForm:password").sendKeys("Aug@2017");
		driver.findElementById("userRegistrationForm:confpasword").sendKeys("Aug@2017");
		driver.findElementById("userRegistrationForm:securityQ").sendKeys("What is your pet name?");
		driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("Mani");
		driver.findElementById("userRegistrationForm:prelan").sendKeys("English");
		driver.findElementById("userRegistrationForm:firstName").sendKeys("Hariharan");
		driver.findElementById("userRegistrationForm:middleName").sendKeys("Rani");
		driver.findElementById("userRegistrationForm:lastName").sendKeys("Shankar");
		driver.findElementByName("userRegistrationForm:gender").click();
		driver.findElementById("userRegistrationForm:maritalStatus:1").click();
		driver.findElementById("userRegistrationForm:dobDay").sendKeys("20");
		driver.findElementById("userRegistrationForm:dobMonth").sendKeys("OCT");
		driver.findElementById("userRegistrationForm:dateOfBirth").sendKeys("1989");
		driver.findElementById("userRegistrationForm:uidno").sendKeys("A123");
		driver.findElementById("userRegistrationForm:idno").sendKeys("P123");
		driver.findElementById("userRegistrationForm:email").sendKeys("hariharan.shankar201089@gmail.com");
		driver.findElementById("userRegistrationForm:mobile").sendKeys("9944427287");
		driver.findElementById("userRegistrationForm:nationalityId").sendKeys("India"); 
		driver.findElementById("userRegistrationForm:address").sendKeys("3/34"); 
		driver.findElementById("userRegistrationForm:street").sendKeys("Aishwary gardens"); 
		driver.findElementById("userRegistrationForm:area").sendKeys("Medavakkam"); 
		driver.findElementById("userRegistrationForm:countries").sendKeys("India");
				
	}

}
