package week1day1;
import java.util.Scanner;

public class NameAgeBloodviaArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		System.out.println("Enter the number of ppl:");
		String numberofppl = hari.nextLine();
		//convert you string to integer
		int count = Integer.parseInt(numberofppl);
		String[] personName=new String[count];
		String[] personAge=new String[count];
		String[] personBloodGroup=new String[count];
		
		for(int i=1;i<=count;i++)
		{
			System.out.println("Enter your name" + i);
			personName[i-1] = hari.nextLine();
			System.out.println("Enter your Age" + i);
			personAge[i-1] = hari.nextLine();
			System.out.println("Enter your Bloodgroup" + i);
			personBloodGroup[i-1] = hari.nextLine();
		}
		for(int i=1;i<=count;i++)
		{
			System.out.println("Person name is " + i + personName[i-1]);
			System.out.println("Person age is "+ i + personAge[i-1]);
			System.out.println("Person age is " + i + personBloodGroup[i-1]);
		}
		if(personAge[i-1].)
		hari.close();
	}
}
