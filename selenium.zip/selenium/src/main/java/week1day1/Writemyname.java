//Pseudocode
//create a class
//create a main function
//print your name
package week1day1;

public class Writemyname {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My Name is Hariharan Shankar");

	}

}
