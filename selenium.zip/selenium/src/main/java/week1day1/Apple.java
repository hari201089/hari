package week1day1;

import org.openqa.selenium.chrome.ChromeDriver;

import wrappers.GenericWrappers;

public class Apple extends GenericWrappers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//launch browser
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Load URL
		driver.get("https://www.smoi.t-systems.com/sm-oi-prod/index.do");
		driver.manage().window().maximize();
		
		//Enter UserName
//		driver.findElement(By.id("LoginUsername")).sendKeys("A0000N1");
//		//Enter Password
//		driver.findElement(By.id("LoginPassword")).sendKeys("Incident123\"");
//		//Click on 'Sign In' button
//		driver.findElement(By.id("loginBtn")).click();
//		//Click on problem record.
//		driver.findElement(By.id("ROOT/Problem Management")).click();
		driver.findElementById("LoginUsername").sendKeys("005L8LV");
		driver.findElementById("LoginPassword").sendKeys("Incident1230&");
		driver.findElementById("loginBtn").click();
		driver.findElementById("ROOT/Problem Management").click();
		//driver.findElementById("ROOT/Problem Management/Problem Queue").click();
		driver.findElementByLinkText("Search Problems").click();
		//driver.findElementByXPath("//a[@Linktext='Search Problems']/span[3]").click();
		//driver.findElementByXPath("//input[@name='instance/id']").sendKeys("PM14204");
		
//			
//				
//		
		
	}

}
