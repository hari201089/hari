package week1day1;
import java.util.Scanner;

public class GetYourName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		System.out.println("Enter your name");
		String myname=hari.nextLine();
		System.out.println("You have entered " + myname);
		hari.close();
	}
}
