package week1day1;
import java.util.Scanner;
public class oddnumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		int fnum,fanswer;
		fnum = hari.nextInt();
		fanswer = fnum % 2;
		if (fanswer==1){
			System.out.println("Entered number is odd");
		}else{
			System.out.println("Entered number is Even");
		}
hari.close();
	}

}
