package week1day1;
import java.util.Scanner;

public class NameAgeBloodandcomp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		System.out.println("Enter the number of ppl:");
		String numberofppl = hari.nextLine();
		//convert you string to integer
		int count = Integer.parseInt(numberofppl);
		String[] personName=new String[count];
		String[] personAge=new String[count];
		String[] personBloodGroup=new String[count];

		for(int i=1;i<=count;i++)
		{
			System.out.println("Enter your name" + i);
			personName[i-1] = hari.nextLine();
			System.out.println("Enter your Age" + i);
			personAge[i-1] = hari.nextLine();
			System.out.println("Enter your Bloodgroup" + i);
			personBloodGroup[i-1] = hari.nextLine();
			}
		int eldestpersonIndex=-1;
		int eldestPersonAge = 0;
		//eldestpersonIndex=personAge[0];
		for(int i=1;i<count;i++)
		{
			int agecount[i] = Integer.parseInt(personAge[i-1]);
			if(agecount[0]>eldestPersonAge){
				eldestPersonAge=agecount[i];
				eldestpersonIndex=i;
			}
			elseif(personAge[1]>eldestPersonAge){
				eldestPersonAge=personAge[i+1];
				eldestpersonIndex=i+1;
			}
			elseif(personAge[2]>eldestPersonAge){
				eldestPersonAge=personAge[i+2];
				eldestpersonIndex=i+2;
			}
			else{
				eldestPersonAge=personAge[i+3];
				eldestpersonIndex=i+2;	
			}
		}

		hari.close();
	}
}
