//Launch the browser
//Enter the username
//Enter the password
//Click Login
//Click crm/sfa link
//Click Leads link
//Click Find leads
//Enter first name
//Click Find leads button
//Click on first resulting lead
//Verify title of the page
//Click Edit
//Change the company name
//Click Update
//Confirm the changed name appears
//Close the browser (Do not log out)

package tests;

import org.testng.annotations.Test;

import wrappers.GenericWrappers;
import wrappers.ProjectSpecificWrapper;

public class EditLeadWrapper extends ProjectSpecificWrapper {
	//@Test(dependsOnMethods="tests.CreateLeadWrapper.createlead")
	@Test(groups={"sanity"})
	public void Editlead() {
		
		
		//GenericWrappers gw = new GenericWrappers();
//		invokeApp("chrome", "http://leaftaps.com/opentaps");
//		enterById("username", "DemoSalesManager");
//		enterById("password", "crmsfa");
//		clickByClassName("decorativeSubmit");
//		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Find Leads");
		enterByXpath("(//input[@name='firstName'])[3]","Hariharan");
		clickByXpath("//button[text()[contains(.,'Find Leads')]]");
		clickByLink("10186");
		verifytitle("View Lead | opentaps CRM");
		clickByLink("Edit");
		enterById("updateLeadForm_companyName", "wipro");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_companyName_sp", "wipro (10186)");
//		closeBrowser();
		

		
		}

}









