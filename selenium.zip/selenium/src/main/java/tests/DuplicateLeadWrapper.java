//Launch the browser
//Enter the username
//Enter the password
//Click Login
//Click crm/sfa link
//Click Leads link
//Click Find leads
//Click on Email
//Enter Email
//Click find leads button
//Capture name of First Resulting lead
//Click First Resulting lead
//Click Duplicate Lead
//Verify the title as 'Duplicate Lead'
//Click Create Lead
//Confirm the duplicated lead name is same as captured name
//Close the browser (Do not log out)

package tests;


import org.testng.annotations.Test;

import wrappers.GenericWrappers;
import wrappers.ProjectSpecificWrapper;

public class DuplicateLeadWrapper extends ProjectSpecificWrapper {
	@Test(groups={"regression"})
	public void Duplicatelead() {
		
		
		//GenericWrappers gw = new GenericWrappers();
//		invokeApp("chrome", "http://leaftaps.com/opentaps");
//		enterById("username", "DemoSalesManager");
//		enterById("password", "crmsfa");
//		clickByClassName("decorativeSubmit");
//		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("(//em[@class='x-tab-left'])[3]");
		enterByName("emailAddress", "karthik@gmail.com");
		clickByXpath("(//button[@class='x-btn-text'])[7]");
		verifyTextlinktext("linktext","Karthik");
//		verifyTextByname("class","linktext");
		//verifyTextByXpath("//a[@linkText='Karthik']","Karthik");
		clickByXpath("(//a[@class='linktext'])[6]");
		clickByLink("Duplicate Lead");
		verifyTextById("sectionHeaderTitle_leads","Duplicate Lead");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp","Karthik");
//		closeBrowser();
		
			
		}

}









