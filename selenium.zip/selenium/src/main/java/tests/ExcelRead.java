package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelRead {
	@Test
	public static String[][] ReadExcel() throws IOException, InvalidFormatException{
		//Get file path
		FileInputStream fis=new FileInputStream(new File("./data/Login.xlsx"));
		//Open workbook
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		//Open sheet
		XSSFSheet sheet=wb.getSheet("Sheet1");
		//Focus row
		XSSFRow row=sheet.getRow(0);
		//Get the total used row count
		int rowcount = sheet.getLastRowNum();
		System.out.println(rowcount);
		//Get last cell number
		int colcount=row.getLastCellNum();
		System.out.println(colcount);
		//Iterate row values
		for(int i=1;i<=rowcount;i++){
			XSSFRow row1=sheet.getRow(i);
			//Iterate column values
			for(int j=0;j<colcount;j++){
				XSSFCell cell=row1.getCell(j);
				System.out.println(cell.getStringCellValue());
			}
		}
		return null;


	}

}
