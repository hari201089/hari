package tests;

import org.junit.Test;

import wrappers.GenericWrappers;

public class IRCTCSwitchWindow extends GenericWrappers {
	@Test
	public void createlead() {
		
		
		//GenericWrappers gw = new GenericWrappers();
		invokeApp("chrome", "https://www.irctc.co.in/eticketing/loginHome.jsf");
//		enterById("username", "DemoSalesManager");
//		enterById("password", "crmsfa");
//		clickByClassName("decorativeSubmit");
		geturl();
		gettitle();
		clickByLink("Contact Us");
		switchToLastWindow();
//		geturl();
//		gettitle();
		switchToParentWindow();
		closeBrowser();
		
//		clickByLink("Leads");
//		clickByLink("Create Lead");
//		enterById("createLeadForm_companyName", "ha242758");
//		enterById("createLeadForm_firstName", "Hariharan");
//		enterById("createLeadForm_lastName", "Shankar");
//		clickByName("submitButton");		
		}

}









