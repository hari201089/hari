//Action Desc
//Launch the browser
//Enter the username
//Enter the password
//Click Login
//Click crm/sfa link
//Click Create Lead
//Enter Company Name
//Enter First Name
//Enter Last Name
//Enter First Name(Local)
//Enter Last Name(Local)
//Enter Salutation
//Choose Source
//Enter Title
//Enter Annual Revenue
//Choose Industry
//Choose Ownership
//Enter SIC Code
//Enter Description
//Enter Important Note
//Enter Country Code
//Enter Area Code
//Enter Extension
//EnterDepartment
//Choose Preferred Currency
//Enter Number Of Employees
//Enter Ticker Symbol
//Enter Person to Ask For
//Enter Web Url
//Enter To Name
//Enter Address Line�1 and 2
//Enter City
//Choose State/Province
//Choose Country
//Enter Zip/Postal Code
//Enter Zip/Postal Code Extension
//Choose Marketing Campaign
//Enter phone number
//Enter email address
//Click Create lead
//Verify the first name
//Close the browser (Do not log out)


package tests;


import org.testng.annotations.Test;

import wrappers.GenericWrappers;

public class Apple2 extends GenericWrappers {
	@Test
	public void createlead() {
		
		
		//GenericWrappers gw = new GenericWrappers();
		invokeApp("chrome", "https://www.smoi.t-systems.com/sm-oi-prod/index.do");
		enterById("LoginUsername", "005L8LV");
		enterById("LoginPassword", "Incident1230&");
		clickById("loginBtn");
		implicitwait(10);
		clickByXpath("(//span[@class='x-panel-header-text'])[6]");
		clickByXpath("(//a[@class='x-tree-node-anchor'])[30]");
		
		enterByXpath("//div[@id='X13Edit']/input", "pm14054");
		clickByXpath("//button[text()='Search']");
		
		
		//search pbm-pm14054-click search button-updates--activity--journal updates--capture value
		/*clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", "ha242758");
		enterById("createLeadForm_firstName", "Hariharan");
		enterById("createLeadForm_lastName", "Shankar");
		//enterByXpath("//select[@id='createLeadForm_marketingCampaignId']","Automobile");
		//clickByName("submitButton");
		enterById("createLeadForm_firstNameLocal", "harry");
		enterById("createLeadForm_lastNameLocal", "shank");
		enterById("createLeadForm_personalTitle", "Harithegreat");
		selectVisibileTextById("createLeadForm_dataSourceId","Conference");
		enterById("createLeadForm_generalProfTitle", "Testleaf");
		enterById("createLeadForm_annualRevenue", "500000");
		selectVisibileTextById("createLeadForm_industryEnumId","Media");
		selectVisibileTextById("createLeadForm_ownershipEnumId","Partnership");
		enterById("createLeadForm_sicCode", "mycode");
		enterById("createLeadForm_description", "mydesc");
		enterById("createLeadForm_importantNote", "mynote");
		enterById("createLeadForm_primaryPhoneCountryCode", "12");
		enterById("createLeadForm_primaryPhoneAreaCode", "34");
		enterById("createLeadForm_primaryPhoneExtension", "44");
		enterById("createLeadForm_departmentName", "java");
		selectVisibileTextById("createLeadForm_currencyUomId", "JPY - Japanese Yen");
		enterById("createLeadForm_numberEmployees", "4");
		enterById("createLeadForm_tickerSymbol", "myticker");
		enterById("createLeadForm_primaryPhoneAskForName", "hari");
		enterById("createLeadForm_primaryWebUrl", "weburl.com");
		enterById("createLeadForm_generalToName", "myname");
		enterById("createLeadForm_generalAddress1", "myaddress");
		enterById("createLeadForm_generalCity", "chennai");
		selectVisibileTextById("createLeadForm_generalCountryGeoId", "India");
		selectVisibileTextById("createLeadForm_generalStateProvinceGeoId", "TAMILNADU");
		enterById("createLeadForm_generalPostalCode", "12");
		enterById("createLeadForm_generalPostalCodeExt", "23");
		
		
		//enterById("createLeadForm_primaryPhoneNumber", "1234567890");
		//enterByXpath("(//input[@name='primaryPhoneNumber'])[4]","9952861523");
		//*[@id="createLeadForm_primaryPhoneNumber"]
		enterById("createLeadForm_primaryEmail", "just@gmail.com");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp", "Hariharan");
		//clickByName("submitButton");
		closeBrowser();
		
		
		//*[@id="createLeadForm_primaryPhoneNumber"]
		}
*/
}
}









