/*Pseudocode:
	define a member function arraynum()
	declare an array and store the array value in a;
	in for loop, initiaise i from 0 and till the length-1 of any array and increment it.
		put one more for loop,initialise j=i+1; till the length of array and increment the j value
				Check a[i]=a[j] and i!=j;
				in sysout print the value of a[j];
				Call the member function from static main method
				*/

package homeworks;

/**
 * This program is to find the repeated numbers in array of numbers.
 * @author Hariharan
 *
 */
public class ArrayofNumbers {
	public void arraynum() {
		// TODO Auto-generated method stub
		int [] a = {13,15,67,88,65,13,99,67,65,87};

		for (int i = 0; i < a.length-1; i++)
		{
			for (int j = i+1; j < a.length; j++)
			{
				if( (a[i]==a[j]) && (i != j) )
				{
					System.out.println("Duplicate number is : "+a[j]);
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayofNumbers ar=new ArrayofNumbers();
		ar.arraynum();

	}

}
