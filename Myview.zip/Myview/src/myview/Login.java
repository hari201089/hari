package myview;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;
@Test
public class Login {
RemoteWebDriver driver;
	public void myviewlogin() {
		System.setProperty("webdriver.chrome.driver",".//drivers//chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://tde-ua1.statestr.com/osagmo/html/myview/index.jsp");
		System.out.println(driver.getTitle());
		driver.findElementByName("username").sendKeys("p539621");
		driver.findElementByName("PASSWORD").sendKeys("Great!001");
		driver.findElementByXPath("//input[@value='Submit']").click();
		String txt=driver.findElementByXPath("//div[text()='MYVIEW']").getText();
		System.out.println(txt);
		
	}

}
