package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Loginpage;
import wrappers.wordpressWrappers;

public class TC_001_Myviewlogin extends wordpressWrappers{
	@BeforeClass
	public void testDetails(){
	
		testCaseName = "TC_001_Myviewlogin";
		testDescription = "Login to Myview";
		category = "Smoke";
		authors = "Hari";
		browserName = "chrome";
		dataSheetName = "MyviewLogin";
		
	}
	
	@Test(dataProvider="fetchData")
	public void login(String uname,String pwd,String site){
		new Loginpage(driver,test)
		.enterusername(uname)
		.enterpassword(pwd)
		.clicksubmitbutton()
		.verifysitename(site);
		
	}

}
