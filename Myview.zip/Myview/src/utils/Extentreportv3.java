package utils;

import org.junit.Assert;

public class Extentreportv3 {
public void passtest(){
	System.out.println("This is my pass method");
	Assert.assertTrue(true);
	
}
}
