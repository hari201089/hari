package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.MyviewWrappers;

public class Loginpage extends MyviewWrappers {
			public Loginpage(RemoteWebDriver driver,ExtentTest test){
			this.driver=driver;
			this.test=test;
			if(!verifyTitle("State Street Login")){
				reportStep("This is not MyView loginpage", "FAIL");
			}		}
			public Loginpage enterusername(String data){
				enterByName("username", data);
				return this;
			}
			
			public Loginpage enterpassword(String data){
				enterByName("PASSWORD", data);
				return this;
			}
			
					
			public MyviewHomepage clicksubmitbutton(){
				clickByXpath("//input[@value='Submit']");
				return new MyviewHomepage(driver,test);
			}
}
