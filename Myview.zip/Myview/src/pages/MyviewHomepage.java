package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.MyviewWrappers;

public class MyviewHomepage extends MyviewWrappers{
	public MyviewHomepage(RemoteWebDriver driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		this.test=test;
		if(!verifyTitle("MyView")){
			reportStep("This is not MyView homepage", "FAIL");
		}		
	}
public MyviewHomepage verifysitename(String data){
	verifyTextContainsByXpath("//div[text()='MYVIEW']", data);
	return this;
}
}
