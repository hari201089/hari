package excel;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;

public class DP {

	@DataProvider(name = "fetchData")
	public Object[][] getData() throws InvalidFormatException, IOException{	
		return ExcelRead.ReadExcel();	
	}	
}






