package excel;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;



public class NewTest {
	ExtentHtmlReporter Report;
	ExtentReports extent;
	ExtentTest  Test;

	
	@BeforeTest
	public void startup()
	{
		Report = new ExtentHtmlReporter("D:\\Sample.html");
		extent = new ExtentReports();
		
		extent.attachReporter(Report);
		extent.setSystemInfo("Host Name", "Windows 10");
		extent.setSystemInfo("Environment", "UAT");
		extent.setSystemInfo("User Name", "Hari");
		
		Report.config().setDocumentTitle("Title of the Report Comes here");
		Report.config().setReportName("Name of the Report Comes here");
		Report.config().setTestViewChartLocation(ChartLocation.TOP);
		Report.config().setTheme(Theme.STANDARD);
		
	    
	    
	}
	
	
	
  @Test
  public void f() 
  {
	  Test = extent.createTest("DemoPass","Test one");
	  Assert.assertTrue(true);
	  
	  
  }
  
  @Test
  public void f2() 
  {
	  Test = extent.createTest("DemoFail","Test Two");
	  Assert.assertTrue(false);
  }
  
  @Test
  public void f3() 
  {
	  Test = extent.createTest("DemoSkip","Test Three");
	  throw new SkipException("This test will be skipped");
	  
  }
  
  @AfterMethod
  public void getResult(ITestResult result)
  {
	  if(result.getStatus()==ITestResult.FAILURE)
	  {
		Test.log(Status.FAIL,	 MarkupHelper.createLabel(result.getName()+" Test cases Failed due to below issues ", ExtentColor.RED));
		Test.fail(result.getThrowable());
			 
	  }
	  
	  else if(result.getStatus()==ITestResult.SUCCESS)
	  {
		  Test.log(Status.PASS,	 MarkupHelper.createLabel(result.getName()+" Test cases Passed ", ExtentColor.GREEN));
	  }
	  
	  else 
	  {
		  Test.log(Status.SKIP,	 MarkupHelper.createLabel(result.getName()+" Test cases Skipped ", ExtentColor.YELLOW));
		  Test.skip(result.getThrowable());
	  }
  }
  
  
  @AfterTest
  public void tearDown()
  {
	  extent.flush();
  }
}
