package com.testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.base.TestBase;

public class BankManagerLogin extends TestBase {
	@Test
	public void bankMgrLogin() throws InterruptedException {
		config.getProperty("Inside login test");
		driver.findElement(By.cssSelector(OR.getProperty("bankmgrlgn_Btn"))).click();
		Assert.assertTrue(isElementpresent(By.cssSelector(OR.getProperty("Addcust_Btn"))),"Login not successful");
		config.getProperty("Login Successful");

	}

}
