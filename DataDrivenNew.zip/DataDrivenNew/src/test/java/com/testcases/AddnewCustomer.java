package com.testcases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddnewCustomer {
	@Test(dataProvider="getData")
	public void addNewCust(String fname,String lname,String postcode) {

	}	
	@DataProvider
	public Object[][] getData(){

	}
}
