package testcases;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import objectrepository.Landingpage;
import objectrepository.LoginPage;
import objectrepository.Mainpage;
import utilities.TestBase;

public class TC_01_LoginTest extends TestBase {
	
	public static Logger log=LogManager.getLogger(TC_01_LoginTest.class.getName());
	
	@BeforeMethod
	public void invokeApp() throws IOException {
		driver=initializeDriver();
		log.info("Driver is initialized");
		driver.get(prop.getProperty("url"));
		log.info("URL is launched");

	}

	@Test
	public void loginApp() throws IOException, InterruptedException {

		Landingpage lp=new Landingpage(driver);
		lp.clickLogin().click();
		log.info("Login link is clicked");
		LoginPage loginobj=new LoginPage(driver);
		loginobj.enterUsername().sendKeys("hariharan.shankar201089@gmail.com");
		log.info("Entered username");
		loginobj.enterPassword().sendKeys("ashwin201089");
		log.info("Entered password");
		loginobj.clickloginSubmit().click();
		log.info("Clicked on loginsubmit");
		Mainpage mp=new Mainpage(driver);
		Thread.sleep(5000);
		Assert.assertEquals(mp.verifyMycourse().getText(), "MY COURSES","Text didnt matches");
		log.info("text verified");

	}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
		driver=null;
		log.info("Browser closed");
	}
}
