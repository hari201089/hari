package tests;


import org.testng.annotations.Test;

import wrappers.GenericWrappers;
import wrappers.ProjectSpecificWrapper;

public class Mergelead extends ProjectSpecificWrapper {
	@Test(groups={"regression"},dependsOnMethods="tests.CreateLeadWrapper.createlead")
	//@Test()
	public void Mergelead1() {
		
		
		//GenericWrappers gw = new GenericWrappers();
		invokeApp("chrome", "http://leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Merge Leads");
		clickByXpath("//table[@id='widget_ComboBox_partyIdFrom']/../a");
		switchToLastWindow();
		//*[@id="ext-gen25"]
		enterByXpath("//div[@class='x-form-element']/input", "10600");
		clickByXpath("//button[text()='Find Leads']");
		implicitwait(5);
		clickByXpathNoSnap("(//a[@class='linktext'])[1]");
		switchToParentWindow();
		verifyTextById("sectionHeaderTitle_leads", "Merge Leads");
		clickByXpath("//table[@id='widget_ComboBox_partyIdTo']/../a");
		switchToLastWindow();
		enterByXpath("//div[@class='x-form-element']/input", "10610");
		clickByXpath("//button[text()='Find Leads']");
		implicitwait(5);
		clickByXpathNoSnap("//a[@class='linktext']");
		switchToParentWindow();
		clickByLinkNoSnap("Merge");
		acceptAlert();
		clickByLink("Find Leads");
		enterByXpath("(//div[@class='x-form-element']/input)[13]", "10600");
		clickByClassName("x-btn-text");
		implicitwait(5);
		verifyTextByXpath("//div[@class='x-paging-info']","No records to display");
		closeBrowser();
		}

}


//
//
//Launch the browser
//Enter the username
//Enter the password
//Click Login
//Click crm/sfa link
//Click Leads link
//Click Merge leads
//Click on Icon near From Lead
//Move to new window
//Enter Lead ID
//Click Find Leads button
//Click First Resulting lead
//Switch back to primary window
//Click on Icon near To Lead
//Move to new window
//Enter Lead ID
//Click Find Leads button
//Click First Resulting lead
//Switch back to primary window
//Click Merge
//Accept Alert
//Click Find Leads
//Enter From Lead ID
//Click Find Leads
//Verify error msg
//Close the browser (Do not log out)
//
//
//
//
