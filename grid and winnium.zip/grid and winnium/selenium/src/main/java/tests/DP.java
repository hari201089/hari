package tests;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class DP extends ExcelRead {

	public Object[][] getData() throws InvalidFormatException, IOException {
		return ExcelRead.ReadExcel();
		
		// TODO Auto-generated method stub

	}

}
