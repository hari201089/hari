//Action Desc
//Launch the browser
//Enter the username
//Enter the password
//Click Login
//Click crm/sfa link
//Click Create Lead
//Enter Company Name
//Enter First Name
//Enter Last Name
//Enter First Name(Local)
//Enter Last Name(Local)
//Enter Salutation
//Choose Source
//Enter Title
//Enter Annual Revenue
//Choose Industry
//Choose Ownership
//Enter SIC Code
//Enter Description
//Enter Important Note
//Enter Country Code
//Enter Area Code
//Enter Extension
//EnterDepartment
//Choose Preferred Currency
//Enter Number Of Employees
//Enter Ticker Symbol
//Enter Person to Ask For
//Enter Web Url
//Enter To Name
//Enter Address Line�1 and 2
//Enter City
//Choose State/Province
//Choose Country
//Enter Zip/Postal Code
//Enter Zip/Postal Code Extension
//Choose Marketing Campaign
//Enter phone number
//Enter email address
//Click Create lead
//Verify the first name
//Close the browser (Do not log out)


package tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import wrappers.GenericWrappers;
import wrappers.ProjectSpecificWrapper;

public class CreateLeadWrapper extends ProjectSpecificWrapper {
	@DataProvider(name="fetchData")
	public Object[][] getData(){
		Object[][] data=new Object[2][3];
		data[0][0]="Testleaf";
		data[0][1]="sethu";
		data[0][2]="sm";
		data[1][0]="google";
		data[1][1]="sarath";
		data[1][2]="N";
		return data;
	}
	@Test(dataProvider="fetchData",invocationCount=2,groups={"smoke"})
	public void createlead(String CompName,String fname,String Lname) {
		
		
		//GenericWrappers gw = new GenericWrappers();
//		invokeApp("chrome", "http://leaftaps.com/opentaps");
//		enterById("username", "DemoSalesManager");
//		enterById("password", "crmsfa");
//		clickByClassName("decorativeSubmit");
//		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", CompName);
		enterById("createLeadForm_firstName", fname);
		enterById("createLeadForm_lastName", Lname);
		//enterByXpath("//select[@id='createLeadForm_marketingCampaignId']","Automobile");
		//clickByName("submitButton");
		enterById("createLeadForm_firstNameLocal", "harry");
		enterById("createLeadForm_lastNameLocal", "shank");
		enterById("createLeadForm_personalTitle", "Harithegreat");
		selectVisibileTextById("createLeadForm_dataSourceId","Conference");
		enterById("createLeadForm_generalProfTitle", "Testleaf");
		enterById("createLeadForm_annualRevenue", "500000");
		selectVisibileTextById("createLeadForm_industryEnumId","Media");
		selectVisibileTextById("createLeadForm_ownershipEnumId","Partnership");
		enterById("createLeadForm_sicCode", "mycode");
		enterById("createLeadForm_description", "mydesc");
		enterById("createLeadForm_importantNote", "mynote");
		enterById("createLeadForm_primaryPhoneCountryCode", "12");
		enterById("createLeadForm_primaryPhoneAreaCode", "34");
		enterById("createLeadForm_primaryPhoneExtension", "44");
		enterById("createLeadForm_departmentName", "java");
		selectVisibileTextById("createLeadForm_currencyUomId", "JPY - Japanese Yen");
		enterById("createLeadForm_numberEmployees", "4");
		enterById("createLeadForm_tickerSymbol", "myticker");
		enterById("createLeadForm_primaryPhoneAskForName", "hari");
		enterById("createLeadForm_primaryWebUrl", "weburl.com");
		enterById("createLeadForm_generalToName", "myname");
		enterById("createLeadForm_generalAddress1", "myaddress");
		enterById("createLeadForm_generalCity", "chennai");
		selectVisibileTextById("createLeadForm_generalCountryGeoId", "India");
		selectVisibileTextById("createLeadForm_generalStateProvinceGeoId", "TAMILNADU");
		enterById("createLeadForm_generalPostalCode", "12");
		enterById("createLeadForm_generalPostalCodeExt", "23");
		
		
		//enterById("createLeadForm_primaryPhoneNumber", "1234567890");
		//enterByXpath("(//input[@name='primaryPhoneNumber'])[4]","9952861523");
		//*[@id="createLeadForm_primaryPhoneNumber"]
		enterById("createLeadForm_primaryEmail", "just@gmail.com");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp", "Hariharan");
		//clickByName("submitButton");
//		closeBrowser();
		
		
		//*[@id="createLeadForm_primaryPhoneNumber"]
		}

}









