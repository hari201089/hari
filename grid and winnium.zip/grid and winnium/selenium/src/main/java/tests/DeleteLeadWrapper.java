/*Launch the browser
Enter the username
Enter the password
Click Login
Click crm/sfa link
Click Leads link
Click Find leads
Click on Phone
Enter phone number
Click find leads button
Capture lead ID of First Resulting lead
Click First Resulting lead
Click Delete
Click Find leads
Enter captured lead ID
Click find leads button
Verify error msg
Close the browser (Do not log out)*/

package tests;


import org.testng.annotations.Test;

import wrappers.GenericWrappers;
import wrappers.ProjectSpecificWrapper;

public class DeleteLeadWrapper extends ProjectSpecificWrapper {
	@Test(groups={"sanity"})
	public void Deletelead() {
		
		
		//GenericWrappers gw = new GenericWrappers();
//		invokeApp("chrome", "http://leaftaps.com/opentaps");
//		enterById("username", "DemoSalesManager");
//		enterById("password", "crmsfa");
//		clickByClassName("decorativeSubmit");
//		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("(//em[@class='x-tab-left'])[2]");
		enterByName("phoneCountryCode","1");
		enterByName("phoneAreaCode","91");
		enterByName("phoneNumber","9894560170");
		clickByXpath("//button[text()='Find Leads']");
		verifyTextByXpath("(//a[@class='linktext'])[4]","Gopi");
		clickByXpath("(//a[@class='linktext'])[4]");
		clickByLink("Delete");
		
		
		/*clickByXpath("(//em[@class='x-tab-left'])[3]");
		enterByName("emailAddress", "karthik@gmail.com");
		clickByXpath("(//button[@class='x-btn-text'])[7]");
		verifyTextlinktext("linktext","Karthik");
//		verifyTextByname("class","linktext");
		//verifyTextByXpath("//a[@linkText='Karthik']","Karthik");
		clickByXpath("(//a[@class='linktext'])[6]");
		clickByLink("Duplicate Lead");
		verifyTextById("sectionHeaderTitle_leads","Duplicate Lead");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp","Karthik");
		closeBrowser();
		*/
			
		}

}









