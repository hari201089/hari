/*Pseudocode
 * Create a member function calculate.
 * initialise member variable num=0;
 * in For loop,
 * initialise i=1; Get the j value via scanner and set condition as i<j  and increment i.
 * To check the program logic use if method and get the reminder either for 3 or 5.
 * Sum the result using num variable.
 * print the sum.
 * In main method, Get the input j via scanner and call the member function call.
 * close the scanner object.
 */

package homeworks;
import java.util.Scanner;
/**
 * This class is used for the calculation of Sum of all multiples of 3 or 5 less than 100
 * @author Hariharan
 *
 */
public class CodingNumber14 {
	/**
	 * Calculate method is responsible for the calculation of Sum of all multiples of 3 or 5 less than 100
	 * @param j
	 * j represents user input
	 */
	public void calculate(int j)
	{
		int num=0;
		for(int i=1;i<j;i++){
			if((i%5==0)||(i%3==0))
			{
				System.out.println(i + "is divisible by 3 or 5");
				num=num+i;
			}		
		}
		System.out.println("sum of divisible(3 or 5) number of "+j+" is "+ num);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari=new Scanner(System.in);
		System.out.println("Enter the max number to check divisible of 3 & 5");
		//hari.nextLine();
		
		int j =hari.nextInt();
		CodingNumber14 cn=new CodingNumber14();
		cn.calculate(j);
		hari.close();

	}

}
