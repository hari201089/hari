package homeworks;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str=new StringBuilder("145525");
		System.out.println(str);
		StringBuilder revstr=str.reverse();
		System.out.println(revstr);
		if(str.equals(revstr)){
			System.out.println("The string/number is palindrome");
		}
		
		else
		{
			System.out.println("Not a palindrome");
		}

	}

}
