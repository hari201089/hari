package homeworks;
import java.util.Scanner;

public class CodingNumber15 {
	
	public void calculate(int fact)
	{
		int mul=0;
		for(int i=fact;i>0;i--){
			for(int j=1;j<i;j++){
				mul=i*j;
				if(mul==fact){
					System.out.println("The factors are"+i+" and" +j);

				}
			}
		}


	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari=new Scanner(System.in);
		System.out.println("Enter the number to find factors");
		int fact =hari.nextInt();
		CodingNumber15 cn=new CodingNumber15();
		cn.calculate(fact);
		System.out.println("Enter the number to prime find factors");
		int pfact=hari.nextInt();
		int x=2;
		while(pfact>1)
		{
			if(pfact%x == 0)
			{
				System.out.print(x+" ");
				pfact=pfact/x;
			}
			else
				x++;
		}
		hari.close();
	}

}
