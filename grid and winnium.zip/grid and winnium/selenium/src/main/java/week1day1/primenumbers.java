package week1day1;

import java.util.Scanner;

public class primenumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		int n,i,count=0;
		n = hari.nextInt();
		for (i=1;i<=n;i++){
			if(n%i==0)
			{
				count++;
			}
		}
			if (count==2){
			System.out.println("Entered number is prime");
		}else{
			System.out.println("Entered number is not prime number");
		}
	}

}
