package week1day1;
import java.util.Scanner;

public class NameAgeBlood {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner hari = new Scanner(System.in);
		for(int i=0;i<=2;i++)
		{
			System.out.println("Enter your name");
			String myname=hari.nextLine();
			System.out.println("Enter your age");
			int myage=hari.nextInt();
			hari.nextLine();
			System.out.println("Enter your Blood group");
			String myblood=hari.nextLine();
		}
		hari.close();
	}
}
