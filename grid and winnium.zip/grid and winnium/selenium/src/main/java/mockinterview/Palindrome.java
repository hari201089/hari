package mockinterview;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder builder=new StringBuilder("125");
		String rev1=builder.toString();
		String rev=builder.reverse().toString();
		if(rev1.equals(rev)){
			System.out.println("the number is palindrome");
		}
		else{
			System.out.println("Not a palindrome");
		}

	}

}
