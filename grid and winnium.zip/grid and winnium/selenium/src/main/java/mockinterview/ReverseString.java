package mockinterview;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Am a hero";
String nowhitespace=str.replaceAll(" ", "");
System.out.println(nowhitespace);
char[] ch=nowhitespace.toCharArray();
for(int i=ch.length-1;i>=0;i--){
	System.out.print(ch[i]);
}

	}

}
