package mockinterview;

public class CopyAlternate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str={"1,2,3,4,7,8"};
char[] ch=str.toString().toCharArray();
	}

}
