package mockinterview;

import java.util.Scanner;

public class Occurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="I am the winner";
		int i,count=0;
		Scanner hari=new Scanner(System.in);
		char ch=hari.next().charAt(0);
		for(char eachch:str.toCharArray()){
			if(ch==eachch){
				count++;
			}
		}
		System.out.println("count is "+count);


	}

}
