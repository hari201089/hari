package mywipro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import wrappers.GenericWrappers;

public class Loginwipro extends GenericWrappers {
	
	RemoteWebDriver driver;
public void login() throws InterruptedException{
	//driver=new ChromeDriver();
	invokeApp("chrome","https://mywipro.wipro.com");
	clickByXpathNoSnap("//img[@class='largeIcon float']");
	enterById("userNameInput","ha242758@wipro.com");
	enterById("passwordInput","Nov@2017");
	clickById("submitButton");
	WebElement close;
	WebDriverWait wait=new WebDriverWait(driver,30);
	close=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='appstr_arrw2_task']")));
	close.click();
	System.out.println("close is clicked");
	
}
	public static void main(String[] args) throws InterruptedException {


		Loginwipro obj=new Loginwipro();
		obj.login();
		
	}

}
